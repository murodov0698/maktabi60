<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-02 07:23:39 --> Severity: Notice  --> Undefined variable: array_or_object_you_want_to_print D:\Program\server\www\sms\data\views\debug.php 60
