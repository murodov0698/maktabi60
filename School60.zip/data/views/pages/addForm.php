<?php

/* 
 *  Author: Dan Aleko
 *  Project: School Managment System
 *  Team: Amrit, Prayash, Ronash, Saroj
 */


