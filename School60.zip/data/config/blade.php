<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['views_path'] = APPPATH . 'views/';
$config['cache_path'] = APPPATH . 'cache/templete/';