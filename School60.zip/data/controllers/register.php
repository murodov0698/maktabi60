<?php if ( ! defined('BASEPATH')) show_404();?>

<?php

/* 
 *  Author: Dan Aleko
 *  Project: Hotel Management NBPI
 *  Group: Dope developers
 */
//Visit "codeastro.com" for more projects!
class Register extends CI_Controller{
    
    public function index(){
       if ($this->aauth->is_loggedin()){
         
                     redirect("welcome");
       }else{
        $this->load->view("public/register");
       }
    }
    
}
