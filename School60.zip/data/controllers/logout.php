<?php

/* 
 *  Author: Dan Aleko
 *  Project: Hotel Management NBPI
 *  Group: Dope developers
 */
//Visit "codeastro.com" for more projects!
class Logout extends CI_Controller{
    
    public function index(){
        
        $this->sms->logout();
        redirect("login");
    }
    
}


